from django.contrib import admin
from .models import TransportRequest,RiderTravelInfo,MatchedAssets

# admin.site.register(TransportRequest)
# admin.site.register(RiderTravelInfo)
# admin.site.register(MatchedAssets)
class TransportRequestAdmin(admin.ModelAdmin):
    model = TransportRequest
    list_display = ['source','destination','date_and_time','flexible_timings','no_of_assets','asset_types','asset_senstivity','requested_by','status'] 
    # list_editable = ['quantity', 'description', 'tax_rate', ] 
class RiderTravelInfoAdmin(admin.ModelAdmin):
    model =RiderTravelInfo
    list_display = ['source','destination','date_and_time','flexible_timings','no_of_assets','travel_medium','status'] 

class MatchedAssetsAdmin(admin.ModelAdmin):
    model =RiderTravelInfo
    list_display = ['request','rider'] 
 

admin.site.register(TransportRequest,TransportRequestAdmin)
admin.site.register(RiderTravelInfo,RiderTravelInfoAdmin)
admin.site.register(MatchedAssets,MatchedAssetsAdmin)